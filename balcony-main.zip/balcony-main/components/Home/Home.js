import { useEffect } from 'react';
import { useRouter } from 'next/router';

import styles from './Home.module.css';

export default function Home () {

  const router = useRouter();

  /**
   * getJwtToken
   */
  const getJwtToken = () => {

    return localStorage.getItem('access_token');
  };

  /**
   * userInfo
   */
  const userInfo = async () => {

    const token = getJwtToken();

    try {

      const request = await fetch(`http://localhost:3001/user/info`, {
        credentials: 'include',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      const response = await request.json();

      return (response && response.success) || false;
    }
    catch (error) {
      
      return false;
    }
  };

  /**
   * gotoLogout
   */
  const gotoLogout = async () => {

    const token = getJwtToken();

    const request = await fetch(`http://localhost:3001/logout`, {
      credentials: 'include',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    const response = await request.json();

    if (response && response.success) {

      localStorage.removeItem('access_token');

      router.push('/login');
    }
  };

  /**
   * On component mount
   */
  useEffect(() => {

    userInfo().then(user => {
      
      console.log(user);

      if (!user) {
        router.push('/login');
      }
    });
  }, []);

  /**
   * Render
   */
  return (
    <div className={styles['home']}>

      <h1>Área logada</h1>
      
      <br /> <br />

      <a href="#" onClick={gotoLogout}>Sair</a>

    </div>
  );
};
