import { useState } from 'react';
import { useRouter } from 'next/router';

import styles from './Login.module.css';

import Link from 'next/link';

export default function Login () {

  const router = useRouter();

  /**
   * State
   */
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(null);

  /**
   * onSubmit
   */
  const onSubmit = async (event) => {

    event.preventDefault();

    const data = new FormData(event.target);

    try {

      setLoading(true);

      const request = await fetch(`http://localhost:3001/user/validate`, {
        method: 'POST',
        body: data,
        credentials: 'include',
      });

      const response = await request.json();

      if (response
        && response.success
        && response.token) {
        
        event.target.reset();

        localStorage.setItem('access_token', response.token);
        
        setSuccess(true);

        setTimeout(() => router.push('/'), 500);
      }
      else {
        setSuccess(false);
      }
    }
    catch (error) {
      setSuccess(false);
    }
    finally {

      setLoading(false);
    }
  };

  /**
   * Render
   */
  return (
    <div className={styles['login']}>
      
      <form className={styles['login__form']} onSubmit={onSubmit}>
        <h1 className="h3 mb-3 fw-normal">Login</h1>

        <div className={[styles['login__input'], 'form-floating'].join(' ')}>
          <input name="email" type="email" className="form-control" id="email" placeholder="nome@exemplo.com" required />
          <label htmlFor="email">Endereço de e-mail</label>
        </div>

        <div className={[styles['login__input'], 'form-floating'].join(' ')}>
          <input name="password" type="password" className="form-control" id="password" placeholder="Senha" required />
          <label htmlFor="password">Senha</label>
        </div>

        {success !== null && (
          <p className={styles['login__message']}>
            {success ? 'Logado com sucesso!' : 'Usuário ou senha inválidos, tente novamente.'}
          </p>
        )}

        <button className={[styles['login__submit'], 'w-100 btn btn-lg btn-primary'].join(' ')} type="submit">
          {loading ? 'Aguarde...' : 'Entrar'}
        </button>

        <div className={styles['login__register']}>
          ou, <Link href="/register">cadastre-se</Link>.
        </div>
      </form>

    </div>
  );
};
